exports.handler = async function(event) {
  try {
    const { code } = JSON.parse(event.body);
    const accessCode = code.toUpperCase();
    
    // 简单的访问码验证
    if (accessCode === 'ADMIN') {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'admin',
          expiry: null
        })
      };
    }

    // 学生访问码验证
    if (accessCode === 'STU2024') {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'user',
          expiry: null
        })
      };
    }

    return {
      statusCode: 401,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: '无效的访问码' })
    };
  } catch (error) {
    console.error('Error validating code:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: '服务器错误' })
    };
  }
} 